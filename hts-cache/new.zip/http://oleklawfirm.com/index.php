<!DOCTYPE html>
<html lang="en" class="ko_Theme ko_ThemeHeader--section">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="generator" content="Kopage">
	<meta name="description" content="">
	<meta name="keywords" content="">

	<title>Oleksandr Lawfirm</title>

	<link rel="preconnect" href="https://fonts.googleapis.com" crossorigin><link rel="dns-prefetch" href="https://fonts.googleapis.com" crossorigin>
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="dns-prefetch" href="https://fonts.gstatic.com" crossorigin>
	<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin><link rel="dns-prefetch" href="https://cdn.jsdelivr.net" crossorigin>

	<base href="/">
	<link rel="shortcut icon" href="//oleklawfirm.com/editor_images/favicon.png">
	<link rel="apple-touch-icon" href="//oleklawfirm.com/editor_images/favicon.png">

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.min.js" type="text/javascript"></script>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="//oleklawfirm.com/inc/live.css?v=4.7.7" type="text/css" rel="stylesheet"><link href="//fonts.googleapis.com/css?family=Montserrat:200,400,700|Lato:200,400,700&amp;subset=latin-ext&amp;display=swap" rel="stylesheet" type="text/css">
	

	<!--[if lt IE 9]><script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script><script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script><![endif]-->

	<style>:root{--ui-color-accent: #179BD7;--ui-color-accent-75: rgba(23,155,215,0.7);--ui-color-accent-50: rgba(23,155,215,0.5);--ui-color-accent-25: rgba(23,155,215,0.25);--ui-color-accent-light: rgba(23,155,215,0.1);--ui-color-stripes-accent:repeating-linear-gradient(
	-45deg,#005f9b,#179BD7 20px,#005f9b 20px,#005f9b 50px,#179BD7 50px,#179BD7 65px);--ui-color-leftmenu:#293A4A;}</style><style>.ko_Theme .topmenu a:hover, .ko_Theme .topmenu .active a {background:inherit}.ko_Theme .menuHolder li a {margin: 0;padding: 0;border: 0;font-size: 100%;font: inherit;vertical-align: baseline;line-height: 1;color: inherit;text-shadow: none}.ko_Theme .menuHolder li {display: inline-block;padding:0}.ko_Theme .menuHolder{ flex-flow: row wrap}.ko_Theme .menuHolder,.ko_Theme #headerMenu{padding:0}.ko_Theme .logoHolder #logoReplacer h2,.ko_Theme .logoHolder a,.ko_Theme .logoHolder {line-height:1;padding:0;margin:0;height:auto}.ko_Theme .logoHolder img{max-height:auto}.ko_Theme #headerMenu .container {/*overflow:auto;*/display:flex;flex-direction: row;justify-content: space-between;align-items: center}:root{--color1:#808080;--color2:#542344;--color1_rgb: 128,128,128;--color1_hsl: 0,0%,50%;--color1_hs: 0,0%;--color1_h: 0;--color1_s: 0%;--color1_l: 50%;--color1_25:#dfdfdf;--color1_50:#c0c0c0;--color1_75:#a0a0a0;--color1_125:#606060;--color1_150:#404040;--color1_175:#202020;--color2_rgb: 84,35,68;--color2_hsl: 320,41%,23%;--color2_hs: 320,41%;--color2_h: 320;--color2_s: 41%;--color2_l: 23%;--color2_25:#d4c8d0;--color2_50:#aa91a2;--color2_75:#7f5a73;--color2_125:#3f1a33;--color2_150:#2a1222;--color2_175:#150911;--color1_bw:rgba(255,255,255,0.8);--color1_25_bw:rgba(0,0,0,0.8);--color1_50_bw:rgba(0,0,0,0.8);--color1_75_bw:rgba(255,255,255,0.8);--color1_125_bw:rgba(255,255,255,0.8);--color1_150_bw:rgba(255,255,255,0.8);--color1_175_bw:rgba(255,255,255,0.8);--color2_bw:rgba(255,255,255,0.8);--color2_25_bw:rgba(0,0,0,0.8);--color2_50_bw:rgba(255,255,255,0.8);--color2_75_bw:rgba(255,255,255,0.8);--color2_125_bw:rgba(255,255,255,0.8);--color2_150_bw:rgba(255,255,255,0.8);--color2_175_bw:rgba(255,255,255,0.8);;--font1:Montserrat;--font2:Lato;--font3:Helvetica Neue,sans-serif;--color1_rgb: 128,128,128;--color1_hsl: 0,0%,50%;--color1_hs: 0,0%;--color1_h: 0;--color1_s: 0%;--color1_l: 50%;--color1_25:#dfdfdf;--color1_50:#c0c0c0;--color1_75:#a0a0a0;--color1_125:#606060;--color1_150:#404040;--color1_175:#202020;--color2_rgb: 84,35,68;--color2_hsl: 320,41%,23%;--color2_hs: 320,41%;--color2_h: 320;--color2_s: 41%;--color2_l: 23%;--color2_25:#d4c8d0;--color2_50:#aa91a2;--color2_75:#7f5a73;--color2_125:#3f1a33;--color2_150:#2a1222;--color2_175:#150911;--color1_bw:rgba(255,255,255,0.8);--color1_25_bw:rgba(0,0,0,0.8);--color1_50_bw:rgba(0,0,0,0.8);--color1_75_bw:rgba(255,255,255,0.8);--color1_125_bw:rgba(255,255,255,0.8);--color1_150_bw:rgba(255,255,255,0.8);--color1_175_bw:rgba(255,255,255,0.8);--color2_bw:rgba(255,255,255,0.8);--color2_25_bw:rgba(0,0,0,0.8);--color2_50_bw:rgba(255,255,255,0.8);--color2_75_bw:rgba(255,255,255,0.8);--color2_125_bw:rgba(255,255,255,0.8);--color2_150_bw:rgba(255,255,255,0.8);--color2_175_bw:rgba(255,255,255,0.8);}#contentArea .koColor {color:#808080;}ul.koCheckList li:before {background:#808080;}.ko_Theme #website .btn-primary {background-color:var(--color2);border-color:var(--color2);}.ko_Theme #website .btn-outline-primary {color:var(--color2);border-color:var(--color2);}.ko_Theme #website .btn-outline-primary:hover {background-color:var(--color2);color:var(--color1_bw);border-color:var(--color2);}#website .page-item.active .page-link {background-color:#808080;color:var(--color1_bw);border-color:var(--color2);}#contentArea a:not(.btn),#contentArea a.btn-link {color:var(--color2)}#website.koMenu a:not(.btn):not(.koMenuButton),#website.koMenu a.btn-link {color:var(--color2)}.ko_Theme #contentArea, .ko_Theme .koThemeDark #contentArea .whiteShadowContainer {color:rgba(0,0,0,0.6)}#contentArea h1, #contentArea h2, #contentArea h3,#contentArea h1 a, #contentArea h2 a, #contentArea h3 a, .koThemeDark #contentArea .whiteShadowContainer strong, .koThemeDark #contentArea .whiteShadowContainer h1, .koThemeDark #contentArea .whiteShadowContainer h2, .koThemeDark #contentArea .whiteShadowContainer h3{color: rgb(0, 0, 0);}#contentArea h4, #contentArea h5, #contentArea h6,#contentArea h4 a, #contentArea h5 a, #contentArea h6 a, .koThemeDark #contentArea .whiteShadowContainer strong, .koThemeDark #contentArea .whiteShadowContainer h4, .koThemeDark #contentArea .whiteShadowContainer h5, .koThemeDark #contentArea .whiteShadowContainer h6 {color: rgb(0, 0, 0);}.ko_Theme #website #footerContent {color: rgba(0, 0, 0, .6);}.ko_Theme #website #footerContent h1,.ko_Theme #website #footerContent h2,.ko_Theme #website #footerContent h3,.ko_Theme #website #footerContent h4,.ko_Theme #website #footerContent h5,.ko_Theme #website #footerContent h6 {color: rgb(0, 0, 0);}.ko_Theme #website, .ko_Theme #website p{font-family:var(--font2),sans-serif;}.ko_Theme #website a.btn, .ko_Theme #website button.btn{font-family:var(--font1),sans-serif;}.ko_Theme #website h1,.ko_Theme #website h2,.ko_Theme #website h3{font-family:var(--font1),sans-serif;font-weight:400}.ko_Theme #website h4,.ko_Theme #website h5,.ko_Theme #website h6{font-family:var(--font1),sans-serif;font-weight:400}.ko_Theme #website .topmenu{font-family:var(--font1),sans-serif;font-weight:400}.ko_Theme #website .logoHolder .logoContents{font-family:var(--font1),sans-serif;font-weight:400}.ko_Theme #website #footerContent {font-family:var(--font2),sans-serif;}.ko_Theme #website #footerContent h1,.ko_Theme #website #footerContent h2,.ko_Theme #website #footerContent h3,.ko_Theme #website #footerContent h4,.ko_Theme #website #footerContent h5,.ko_Theme #website #footerContent h6 {font-family:var(--font1),sans-serif;}.ko_Theme .menuHolder li.topmenuSocial > span{margin-top:0px;}.ko_Theme #headerContent:not(.koZeroPadding),.ko_Theme #subpageHeaderContent:not(.koZeroPadding){}.ko_Theme #headerMenu{/*overflow:auto;*//*display:flex;flex-direction: row;justify-content: space-between;align-items: center;*/background:rgb(255, 255, 255);padding:20px;margin:0px;border:10px solid var(--color1);border-width:10px 0px 0px 0px;border-radius:0px;box-shadow:0 .4375rem 1.8125rem 0 rgba(0,0,0,.09);;}.ko_Theme .logoHolder{padding:0px;;white-space: nowrap;}.ko_Theme .logoHolder .logoContents{font-size:24px;color:rgb(0, 0, 0);display: flex;align-items: center;min-height:40px;}@media (max-width: 768px){.ko_Theme .logoHolder .logoContents{font-size:22px;}}.ko_Theme .logoHolder img{max-height:40px;height:40px;min-height:40px;}.ko_Theme .menuHolder { display: flex;}.ko_Theme .menuHolder li{}.ko_Theme .menuHolder li a{font-size:17px;color:var(--color1);padding:5px 0px 5px 0px;margin:0px 0px 0px 15px;border-radius:0px;border:solid transparent;border-width:0px 0px 2px 0px;text-transform:uppercase;transition:0.2s all;}.ko_Theme .menuHolder li.active a,.ko_Theme .menuHolder li a:hover{color:rgb(0, 0, 0);border-color:var(--color2);}.ko_Theme .menuHolder li.accent1 a,.ko_Theme .menuHolder li.accent1.active a{font-size:17px;color:var(--color1_25);background:var(--color1);padding:15px;margin:0px 0px 0px 30px;border-radius:3px;border:0px solid ;}.ko_Theme .menuHolder li.accent1.active a,.ko_Theme .menuHolder li.accent1 a:hover{color:rgb(255, 255, 255);background:var(--color1_125);}.ko_Theme .menuHolder li.accent2 a,.ko_Theme .menuHolder li.accent2.active a{font-size:17px;color:rgb(255, 255, 255);background:var(--color2);padding:15px;margin:0px 0px 0px 5px;border-radius:3px;border:0px solid rgb(255, 255, 255);}.ko_Theme .menuHolder li.accent2.active a,.ko_Theme .menuHolder li.accent2 a:hover{color:rgb(255, 255, 255);background:var(--color2_125);}.ko_Theme .menuHolder li.topmenuSocial a{color:rgb(0, 0, 0)}</style>
</head>
<body class="" >
<div id="websiteLoading" onclick="var elem = document.getElementById('websiteLoading');elem.parentNode.removeChild(elem);" onkeyup="var elem = document.getElementById('websiteLoading');elem.parentNode.removeChild(elem);" class="isLoading isLoading-1"><div style="background:white;position:absolute;top:0;left:0;right:0;bottom:0;height:100%;width:100%" class="d-none"></div><noscript><style>#websiteLoading{display:none!important}body{visibility:visible!important;overflow:auto!important}</style></noscript><style>		body{overflow:hidden}		body.body{visibility:visible;overflow:auto}		#websiteLoading{visibility:visible;position:fixed;top:0;left:0;right:0;bottom:0;transition:0.5s all;z-index:100000;background: linear-gradient(135deg, rgba(255,255,255,.95) 20%, rgba(255,255,255,.5), rgba(255,255,255,.95) 80%);cursor:wait}		#websiteLoading.isLoading-1{background:#fff;}		#websiteLoading.isLoaded{opacity:0;cursor:default;pointer-events:none}		@-webkit-keyframes koLoadingRotation {		to {			-webkit-transform: rotate(360deg);					transform: rotate(360deg);		}		}		@keyframes koLoadingRotation {		to {			-webkit-transform: rotate(360deg);					transform: rotate(360deg);		}		}		.isLoading .spinner {		-webkit-animation: koLoadingRotation 1.5s linear infinite;				animation: koLoadingRotation 1.5s linear infinite;			/*will-change: transform;*/		}		.isLoading .spinner .path {		-webkit-animation: dash 1.5s ease-in-out infinite;				animation: dash 1.5s ease-in-out infinite;		}		@-webkit-keyframes dash {		0% {			stroke-dasharray: 1, 150;			stroke-dashoffset: 0;			stroke:var(--color1);		}		50% {			stroke-dasharray: 90, 150;			stroke-dashoffset: -35;			stroke:var(--color2);		}		100% {			stroke-dasharray: 90, 150;			stroke-dashoffset: -124;			stroke:var(--color1);		}		}		@keyframes dash {		0% {			stroke-dasharray: 1, 150;			stroke-dashoffset: 0;			stroke:var(--color1);		}		50% {			stroke-dasharray: 90, 150;			stroke-dashoffset: -35;			stroke:var(--color2);		}		100% {			stroke-dasharray: 90, 150;			stroke-dashoffset: -124;			stroke:var(--color1);		}		}		#websiteLoading::after {			content:"";			background: #fff;			border-radius:100%;			box-shadow: 5px 5px 50px rgba(0,0,0,0.1);			position: absolute;			top: 50%;			left: 50%;			margin: -57px 0 0 -57px;			width: 114px;			height: 114px;		}		</style><svg class="spinner" viewBox="0 0 50 50" style="z-index: 2;position: absolute;top: 50%;left: 50%;width:120px;height:120px;	  margin: -60px 0 0 -60px;"><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="2" style="stroke: #ccc; stroke: var(--color1);stroke-linecap: round;"></circle></svg></div><div id="website" class=""><header id="header"><div id="headerMenu"><div class="container"><div class="logoHolder skiptranslate"><a href="/" class="logo"><span class="logoContents"><img src="data/files/oleklogo1.png" id="websiteLogo" alt="Oleksandr &amp; Associates Law Firm"></span></a></div>

	<ul class="menuHolder topmenu" role="navigation">
		<li class="item_active active"><a href="http://oleklawfirm.com"><span>Home</span></a></li>
		<li><a href="about"><span>About</span></a></li>
		<li><a href="services"><span>Services</span></a></li>
		<li><a href="contact"><span>Contact</span></a></li>
		
	</ul>

</div></div></header><main class="WxEditableArea" id="contentArea"><div id="contentAreaElement" class="kelement"></div><section data-pcid="4903" id="kpg_719745" data-keditor="1" class="kedit"><div class="container"><div class="row"><div class="col-lg"><div class="col-container"><div class="mt-2 mb-2 kimgRatio6"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><img class="img-fluid lazy" alt="" title="" data-src="data/files/1762298705.png"></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></div></div></div><div class="col-lg"><div class="col-container"><div class="koPreTitle mt-2 mb-2 keditable"><div>Oleksandr Radchenko</div></div><h1 class="mt-2 mb-2 keditable" style="--kedit-fsx: 1.30;">Protecting Ideas, Powering Innovation. </h1><div class="koSeparator koSeparatorBlock koSeparatorLeft" data-bg="#85144b" style="background: rgb(133, 20, 75); height: 10px; width: 150px; margin-top: 30px; margin-bottom: 30px;"></div><div class="mt-2 mb-2 keditable"><font style="font-size: 130%;">Whether you’re an innovator, artist, entrepreneur, or established business, we’re here to safeguard your intellectual property—so you can create, grow, and lead with confidence.</font></div><div class="koButtons d-flex mt-4 mb-2"><a href="contact" class="btn btn-color2">Schedule a free consultation</a></div></div></div></div></div></section>
<section data-pcid="4005.1" id="kpg_584048" class="kedit keditDark" data-padding="50-50" data-bgcolor="--color2_125" style="background:var(--color2_125);padding-top:50px;padding-bottom:50px">


<div class="row justify-content-center align-contents-center mx-5 mx-md-0 skiptranslate">
<div class="col-12 col-md-auto d-flex align-items-center">
    <span class="koIconStyle22   koIconHolder me-1 ms-0 koIconSize100 koIconSquare"><i class="koIcon fas fa-phone"></i></span> <div class="keditable me-5 ms-3">+380444288144</div>
</div>
<div class="col-12 col-md-auto d-flex align-items-center my-4 my-md-0">
    <span class="koIconStyle22   koIconHolder me-1 ms-0 koIconSize100 koIconSquare"><i class="koIcon fas fa-envelope"></i></span> <div class="keditable me-5 ms-3">contact@oleklawfirm.com</div>
</div>
<div class="col-12 col-md-auto d-flex align-items-center">
    <span class="koIconStyle22   koIconHolder me-1 ms-0 koIconSize100 koIconSquare"><i class="koIcon fas fa-map-marker-alt"></i></span> <div class="keditable ms-3">Dehtiarivska St, 33Б, 4th Floor, No. 17<br>Kyiv,&nbsp; 02000<br>Ukraine</div>
</div>
</div>




</section>
<section data-pcid="4902" id="kpg_860405" data-keditor="1" class="kedit"><div class="container"><div class="row"><div class="col-lg"><div class="col-container"><h1 class="mt-2 mb-2 keditable">About Our Firm.</h1><div class="koSeparator koSeparatorBlock koSeparatorLeft" data-bg="#85144b" style="background: rgb(133, 20, 75); height: 10px; width: 150px; margin-top: 30px; margin-bottom: 30px;"></div><div class="mt-2 mb-2 keditable"><span style="color: rgb(0, 0, 0);"><span style="font-weight: bold;">Oleksandr Radchenko </span>began his legal career after graduating from the Academy of Advocacy of Ukraine in 1997 with a Specialist Degree in Law. He spent a decade under Mikhail Shevchenko, where he refined his expertise in international intellectual property disputes. <br>Following his mentor’s passing in 2020, Oleksandr established his own firm, continuing the principles of precision and integrity he had learned. Over the years, his practice has grown into a respected team of professionals, serving clients worldwide and upholding a reputation for excellence in intellectual property protection and legal strategy.<br><br><br></span></div><div class="koButtons d-flex mt-4 mb-2"><a href="about" class="btn btn-color2">Learn More</a></div></div></div></div></div></section>
<section data-pcid="4904" id="kpg_49932" data-keditor="1" class="kedit"><div class="container"><div class="row"><div class="col-lg"><div class="col-container"><div class="koPreTitle mt-2 mb-2 keditable"><br></div><h1 class="mt-2 mb-2 keditable" style="--kedit-fsx: 1.10;">Our Mission.</h1><div class="koSeparator koSeparatorBlock koSeparatorLeft" data-bg="#85144b" style="background: rgb(133, 20, 75); height: 10px; width: 150px; margin-top: 30px; margin-bottom: 30px;"></div><div class="mt-2 mb-2 keditable"><div><span style="color: rgb(0, 0, 0);">We provide every client — from individuals and startups to global corporations — with partner-level attention and dedicated service. Our goal is to deliver precise, customized legal solutions through a comprehensive perspective, ensuring every case receives the insight it deserves. <br></span></div><div><span style="color: rgb(0, 0, 0);">We are committed to providing personalized counsel and effective resolutions that protect innovation, creativity, and business integrity across borders. <br></span></div></div></div></div><div class="col-lg"><div class="col-container"><div class="kimgRatio mt-2 mb-2"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><span class="keditImageWrap keditImageWrap-dd d-block"><img class="img-fluid lazy" alt="" title="" data-src="data/files/photos/1454165804606-c3d57bc86b40-0e3823a3.jpg"></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></div></div></div></div></div></section>
<section data-pcid="4019" id="kpg_685713" class="kedit" data-keditor="1"><div class="container keditPointerEvents_off">
	                    
	<div class="row justify-content-center align-items-center">
		      
		<div class="col-lg-6 ms-auto keditPointerEvents_on">
            
            
            
            
    <div class="ps-0 ps-lg-5 keditable-block"><div class="col-container">
        
                <div class="koPreTitle keditable" data-aos="fade-left"><br></div>
                <h1 class="keditable" data-aos="fade-left">Our Area of Expertise.</h1>
                
                <div class="koSeparator koSeparatorBlock koSeparatorLeft" data-bg="--color2" data-aos="fade-left" style="background: var(--color2); width: 100px; height: 10px; margin-top: 30px; margin-bottom: 30px;"></div><div class="keditable" data-aos="fade-left"><div><span style="color: rgb(0, 0, 0);">Although based in Ukraine, our firm serves clients worldwide, with specialized expertise in intellectual property across the European Union, the United States, and China.</span>&nbsp; <span style="color: rgb(0, 0, 0);"><br></span></div></div>


                <ul class="koCheckList mt-4 mb-4 keditable"><li>Trademark <br></li><li>Copyrights</li><li>Patent</li><li>Litigation and IP Disputes</li><li>And more...</li>  </ul>



                
        
        
            <div class="koButtons d-flex mt-4 mb-2"><a href="services" class="btn btn-color2">Learn More</a></div></div></div>
            
			      
		</div>
		                  
	</div>
	                   
</div>
    
<div class="pt-5 pt-lg-0 keditExpand keditExpand-lg max-vh-100">
    
    <div class="col-lg-6 me-auto h-100">
	        
		<span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><span class="keditImageWrap keditImageWrap-dd d-block w-100 h-100"><img class="img-full lazy" alt="" title="" data-src="data/files/photos/1626266061368-46a8f578ddd6-1ac04e86.jpg"></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span>    

    </div>
</div></section>
<section data-pcid="4005.1" id="kpg_140382" class="kedit keditDark" data-padding="50-50" data-bgcolor="--color2_125" style="background:var(--color2_125);padding-top:50px;padding-bottom:50px">


<div class="row justify-content-center align-contents-center mx-5 mx-md-0 skiptranslate">
<div class="col-12 col-md-auto d-flex align-items-center">
    <span class="koIconStyle22   koIconHolder me-1 ms-0 koIconSize100 koIconSquare"><i class="koIcon fas fa-phone"></i></span> <div class="keditable me-5 ms-3">+380444288144</div>
</div>
<div class="col-12 col-md-auto d-flex align-items-center my-4 my-md-0">
    <span class="koIconStyle22   koIconHolder me-1 ms-0 koIconSize100 koIconSquare"><i class="koIcon fas fa-envelope"></i></span> <div class="keditable me-5 ms-3">hello@oleklawfirm.com</div>
</div>
<div class="col-12 col-md-auto d-flex align-items-center">
    <span class="koIconStyle22   koIconHolder me-1 ms-0 koIconSize100 koIconSquare"><i class="koIcon fas fa-map-marker-alt"></i></span> <div class="keditable ms-3">Dehtiarivska St, 33Б, 4th Floor, No. 17<br>Kyiv,&nbsp; 02000<br>Ukraine</div>
</div>
</div>




</section></main><footer id="footerContent"><section data-pcid="5500.1" id="kedit_fap7hdc8s" class="kedit keditFooter keditFooter1 keditDark" data-bgcolor="#111111" style="background:#111111">

      <div class="container keditFooterLine1">
          <div class="row">
              <div class="col-lg-4">
                  <div class="kedit" id="kpg_7593861">
                  <span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"><span class="keditImageWrap keditImageWrap-dd"></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span>
                  <div class="keditable skiptranslate mt-4 keditFooterCompany">Oleksandr Radchenko &amp; Associates Law Firm<br>Dehtiarivska St, 33Б, 4th Floor, No. 17<br>Kyiv, 02000<br>Ukraine</div>
                  </div>
              </div>
              <div class="col-lg-8">
                  <div class="kedit keditFooterMenu" id="kpg_4236852"><ul class="sitemap"><li><h5>Main menu</h5>
<ul>

<li data-id="1"><a href="http://oleklawfirm.com/" title="Home" ><span>Home</span></a></li>

<li data-id="2"><a href="about" title="About" ><span>About</span></a></li>

<li data-id="3"><a href="services" title="Services" ><span>Services</span></a></li>

<li data-id="4"><a href="contact" title="Contact" ><span>Contact</span></a></li>
</ul>
</li></ul></div>
              </div>
          </div>
      </div>

      <div class="keditFooterLine2 keditFooterLineDarker">
          <div class="container">
              <div class="row">
                  <div class="col-sm-7">
                      <div class="kedit" id="kpg_4084193"><div class="keditable keditFooterCopyright">Copyright ©2025&nbsp;Oleksandr&nbsp;Radchenko &amp; Associates Law Firm, All rights reserved. <br>Website built with <a href="https://www.kopage.com/" target="_blank">Kopage</a></div></div>
                  </div>
                  <div class="col-sm-5">
                      <div class="kedit keditFooterApp" id="kpg_2674154"><div class="footerHolder" id="keditFooterModule"></div></div>
                  </div>
              </div>
          </div>
      </div>

</section></footer></div><a id="scrollToTop" aria-label="Scroll to Top Button" href="javascript:void(null)"><i class="fa fa-fw fa-arrow-up"></i></a><script data-id="websiteLoading">$(document).ready(function(){

						$('#websiteLoading').removeClass('isLoading-1');
						setTimeout(function(){

							var c=$('#websiteLoading');
							if(c.length>0){
								//$('body').attr('id','body');
								$('body').addClass('body');
								$('#websiteLoading').addClass('isLoaded');
								setTimeout(function(){$('#websiteLoading').remove()},1000);
							}

						},3000);
					});window.onload = function(){$('#websiteLoading').addClass('isLoaded');
				//$('body').attr('id','body');
				$('body').addClass('body');
				setTimeout(function(){$('#websiteLoading').remove()},500);$(document).keyup(function(e){if((e.ctrlKey || e.metaKey)&&e.keyCode==27){window.location.href="?modal=login";}});};</script><script>var koSiteName="Oleksandr & Associates Law Firm";$(function(){$(".koLeftMenuOpener").removeClass("invisible");})</script><div id="searchHolder">
		<form method="get" action="">
			<div>Search</div>
			<input type="text" autocomplete="off" name="search" aria-label="Search Form" id="searchInput" class="form-control">
			<button type="submit" class="btn btn-color1" aria-label="Search"><i class="fas fa-search"></i></button>
			<button type="reset" class="btn btn-light" onclick="$('#searchHolder').removeClass('active')"><i class="fas fa-times"></i></button>
		</form></div><script>var magnificPopupInit=function(){$('a.lightbox').magnificPopup({type:'image',gallery:{enabled:true}});}</script><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/magnific-popup.min.css"><script async src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js" onload="magnificPopupInit()"></script>

<script>var jQueryChecker_interval,jQueryChecker_count=0;$(function(){jQueryChecker_interval=window.setInterval(function(){if(typeof window.$ === "undefined" && typeof window.jQuery === "function"){console.log("jQuery ($) has been lost, restoring...");window.$=window.jQuery}jQueryChecker_count++;if(jQueryChecker_count>10)clearInterval(jQueryChecker_interval)},1000)})</script><script src="https://cdn.jsdelivr.net/npm/instant.page@5.2.0/instantpage.min.js" type="module" defer></script><script>var menuCaption = "Select a page";</script><script type="text/javascript" src="//oleklawfirm.com/inc/live.js?4.7.7" async></script><link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css" rel="stylesheet"><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" type="text/javascript"></script>
	<!-- AOS (Animate on Scroll) -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.min.js" defer></script><script>$(function(){AOS.init({offset:-10,delay:100,duration:800,easing:'ease',anchorPlacement:'top-bottom'});})</script><script>$(function(e){var a = 400,s = e('#scrollToTop');e(window).scroll(function(){e(this).scrollTop() > a ? s.addClass('active') : s.removeClass('active')}), s.on('click',function(a){s.removeClass('active');e('body,html').animate({scrollTop: 0});})})</script>	<style>
		#koHiddenEditor:not(.logoutPlaceholder) {
			bottom: 100px;
		}
	#koby{
		position: fixed;
		left:20px;
		bottom:20px;
		z-index: 99998;
		/*z-index: 65401;*/
		width: auto;


		
	}
	.inAdminMode #koby{
		left:110px;
		bottom:10px;
	}
	#koby img{height:24px;display: block;margin-left:10px;}
	#koby:hover{color:#000}

	#kobya{
		
		display: flex;
		align-items:center;
		flex-wrap: wrap;
		color:#444;
		height:40px;
		position: relative;

		letter-spacing:0.25px;
		font-size: 13px;
		
		background:linear-gradient(to bottom,#fff 60%,#eee);
		
		box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.12),
		0px 2px 2px 0px rgba(0, 0, 0, 0.07), 0px 4px 4px 0px rgba(0, 0, 0, 0.07),
		0px 6px 6px 0px rgba(0, 0, 0, 0.07), 0px 8px 8px 0px rgba(0, 0, 0, 0.07);

	
		border-radius:10px;padding: 0 15px;
		
	}
	#kobyb{

		opacity:0;
		background: var(--ui-color-leftmenu);
		color:#ccc;
		position: absolute;
		line-height:30px;
		font-size:14px;
		z-index: -1;
		display: flex;
		align-items:center;

		border-radius:5px 5px 14px 14px;
		border-radius:14px;
		font-family: var(--ui-system-font),"Helvetica Neue", Helvetica, sans-serif;
		letter-spacing: -0.25px;
		transition:0.2s opacity;

		bottom:5px;left:5px;height:0;padding:0;overflow:hidden;

	}
	#koby:hover #kobyb, #kobyb:hover{

		opacity:1;

		padding:0 10px 45px;
		left: -5px;
		bottom: -5px;
		width: calc(100% + 10px);
		height: inherit;

	}
		</style>
	
	<div id="koby">

		<a id="kobya" href="https://www.kopage.com/free?utm_source=free_badge" target="_blank">
		
			<span>Website made with</span>
			<span><img src="https://www.kopage.com/data/files/kopageheader_orange.svg" alt="Kopage Website Builder"></span>

		
			


		</a>
		<a href="https://www.kopage.com/free?utm_source=free_badge" target="_blank" id="kobyb" class="justify-content-end text-decoration-none">Build a Free Website <i class="fa fa-angle-right ms-2"></i></a>
	</div>

	<script type="text/javascript">$(function(){var dataText="supermode=stats&page=/index.php&referrer=http://oleklawfirm.com/about";$.ajax({type: "POST",url: "index.php",data: dataText,success: function(data) {}});});</script><script type="text/javascript" id="jsMenusSetup">window.addEventListener('load',function(){ddlevelsmenu.setup("1", "topbar","0","0");});</script>
</body></html>